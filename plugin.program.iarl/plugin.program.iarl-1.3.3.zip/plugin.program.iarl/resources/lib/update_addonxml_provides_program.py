from util import *

update_addonxml('executable game')